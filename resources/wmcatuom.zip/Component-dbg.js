sap.ui.define(["sap/fe/core/AppComponent"], function(AppComponent) {
    'use strict';

    return AppComponent.extend("wm.cat.uom.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
